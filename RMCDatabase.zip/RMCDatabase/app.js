var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var bodyParser = require('body-parser');
var costData = require('./routes/costingData');
var services = require('./routes/services');
var quotations = require('./routes/quotations');
var users = require('./routes/users_list');
var cors = require('cors')
var dateFormat = require('dateformat');
const dotenv   = require('dotenv').config();
var app = express();

app.use(cors());
app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});


// view engine setup
//mongodb.mongoPool.start();
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, './client/dist/client')));

app.use('/users', users);
app.use('/cost',costData)
app.use('/api', services);
app.use('/quotations', quotations);

app.get('*', function (req, res) {
    console.log("headers for index -->", JSON.stringify(req.headers));
    res.sendFile(path.join(__dirname, './client/dist/client/index.html'));
});


module.exports = app;

const fs = require('fs');
const path = require('path');
var db = require('../mssql/index');
var util = require('util');
var dateFormat = require('dateformat');
var moment = require('moment-business-days');
var listHolday = ['01-01-2021','14-01-2021','26-01-2021','02-04-2021','13-04-2021','21-04-2021','01-05-2021','14-05-2021','10-09-2021','15-10-2021','04-11-2021'] 
moment.updateLocale('us', {
   holidays: listHolday,
   holidayFormat: 'DD-MM-YYYY'
});
moment.updateLocale('us', {
   workingWeekdays: [1, 2, 3, 4, 5]
});

exports.costShetFileInsert = (Obj) => {
	   console.log(7,Obj)
		 var insertCostSheetFileSql = "INSERT INTO [costSheetFiles] (ClientName,ProposalCode,USDExchangeRate,CustomerCompoundCode,BusinessUnit,SubmittedDate,GMPorNonGMP,FileName,ReceievedDate,ReloadOrNew) VALUES"
       	   
			   insertCostSheetFileSql += util.format("('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",
                Obj.ClientName?Obj.ClientName:'',Obj.ProposalCode?Obj.ProposalCode:'',Obj.USDExchangeRate?Obj.USDExchangeRate:'',Obj.CustomerCompoundCode?Obj.CustomerCompoundCode:'',Obj.BusinessUnit?Obj.BusinessUnit:'',Obj.SubmittedDate?Obj.SubmittedDate:'',Obj.GMPorNonGMP?Obj.GMPorNonGMP:'',Obj.quantity?Obj.quantity:'',Obj.ReceievedDate?Obj.ReceievedDate:'',Obj.ReloadOrNew?Obj.ReloadOrNew:'');
				insertCostSheetFileSql+= "SELECT SCOPE_IDENTITY() AS id";
		db.executeSql(insertCostSheetFileSql, function(errFile, responseFile){
			if(errFile){
				return {error:true,response:errFile}
			}else{
				return {error:false,response:responseFile}
			}
		})
			   

}

exports.dropDowns = (Obj) => {
	var ProposalCode =[]
	var Received = []
	var Name =[]
	var CAS_Number =[]
	var Unit_Cost_Per_Kg_Rs =[]
	var Chemical_category =[]
	var Percentage_of_the_total_cost =[]
	var Country =[]
	var FGQty =[]
	var Con_CC_in_Kg =[]
	var MadeOfShipment =[]
	var Source =[]
	var Lead_time =[]
	var Min_pack =[]
	var Remarks =[]
	var Total_Cost_Rs =[]

	var PCode = Obj.filter((v,i,a)=>a.findIndex(t=>(t.ProposalCode === v.ProposalCode))===i)
	var ReceivedDt = Obj.filter((v,i,a)=>a.findIndex(t=>(t.Received === v.Received))===i)
	var mName = Obj.filter((v,i,a)=>a.findIndex(t=>(t.Name === v.Name))===i)
	var CASNumber = Obj.filter((v,i,a)=>a.findIndex(t=>(t.CAS_Number === v.CAS_Number))===i)
	var UnitCostPerKgRs = Obj.filter((v,i,a)=>a.findIndex(t=>(t.Unit_Cost_Per_Kg_Rs === v.Unit_Cost_Per_Kg_Rs))===i)
	var Chemicalcategory = Obj.filter((v,i,a)=>a.findIndex(t=>(t.Chemical_category === v.Chemical_category))===i)
	var Percentagetotal_cost = Obj.filter((v,i,a)=>a.findIndex(t=>(t.Percentage_of_the_total_cost === v.Percentage_of_the_total_cost))===i)
	var CountryAry = Obj.filter((v,i,a)=>a.findIndex(t=>(t.Country === v.Country))===i)
	var FGQtyAry = Obj.filter((v,i,a)=>a.findIndex(t=>(t.FGQty === v.FGQty))===i)
	var Con_CCKg = Obj.filter((v,i,a)=>a.findIndex(t=>(t.Con_CC_in_Kg === v.Con_CC_in_Kg))===i)
	var MadeOfShipmentAry = Obj.filter((v,i,a)=>a.findIndex(t=>(t.MadeOfShipment === v.MadeOfShipment))===i)
	var SourceAry = Obj.filter((v,i,a)=>a.findIndex(t=>(t.Source === v.Source))===i)
	var Leadtime = Obj.filter((v,i,a)=>a.findIndex(t=>(t.Lead_time === v.Lead_time))===i)
	var Minpack = Obj.filter((v,i,a)=>a.findIndex(t=>(t.Min_pack === v.Min_pack))===i)
	var RemarksAry = Obj.filter((v,i,a)=>a.findIndex(t=>(t.Remarks === v.Remarks))===i)
	var TotalCost_Rs = Obj.filter((v,i,a)=>a.findIndex(t=>(t.Total_Cost_Rs === v.Total_Cost_Rs))===i)

	PCode.forEach((val, index)  => {
		ProposalCode.push(val.ProposalCode)
	})
	ReceivedDt.forEach((val, index)  => {
		var RdateNew=dateFormat(val.Received, "yyyy-mm-dd");
		if (!Received.includes(RdateNew)) {
			Received.push(RdateNew);
		}
	})
	mName.forEach((val, index)  => {
		Name.push(val.Name)
	})
	CASNumber.forEach((val, index)  => {
		CAS_Number.push(val.CAS_Number)
	})
	UnitCostPerKgRs.forEach((val, index)  => {
		Unit_Cost_Per_Kg_Rs.push(val.Unit_Cost_Per_Kg_Rs)
	})
	Chemicalcategory.forEach((val, index)  => {
		Chemical_category.push(val.Chemical_category)
	})
	Percentagetotal_cost.forEach((val, index)  => {
		Percentage_of_the_total_cost.push(val.Percentage_of_the_total_cost)
	})
	CountryAry.forEach((val, index)  => {
		Country.push(val.Country)
	})
	FGQtyAry.forEach((val, index)  => {
		FGQty.push(val.FGQty)
	})
	Con_CCKg.forEach((val, index)  => {
		Con_CC_in_Kg.push(val.Con_CC_in_Kg)
	})
	MadeOfShipmentAry.forEach((val, index)  => {
		MadeOfShipment.push(val.MadeOfShipment)
	})
	SourceAry.forEach((val, index)  => {
		Source.push(val.Source)
	})
	Leadtime.forEach((val, index)  => {
		Lead_time.push(val.Lead_time)
	})
	Minpack.forEach((val, index)  => {
		Min_pack.push(val.Min_pack)
	})
	RemarksAry.forEach((val, index)  => {
		Remarks.push(val.Remarks)
	})
	TotalCost_Rs.forEach((val, index)  => {
		Total_Cost_Rs.push(val.Total_Cost_Rs)
	})
    return {ProposalCode,Received,Name,CAS_Number,Unit_Cost_Per_Kg_Rs,Chemical_category,Percentage_of_the_total_cost,Country,FGQty,Con_CC_in_Kg,MadeOfShipment,Source,Lead_time,Min_pack,Remarks};  
}

exports.costFilesdropDowns = (Obj) => {
	var ProposalCode =[]
	var FileName =[]
	var ClientName =[]
	var GMPorNonGMP =[]
	var USDExchangeRate =[]
	var ReloadOrNew =[]
	var BusinessUnit =[]
	var CustomerCompoundCode =[]
	
	var Fname = Obj.filter((v,i,a)=>a.findIndex(t=>(t.FileName === v.FileName))===i)
	var PCode = Obj.filter((v,i,a)=>a.findIndex(t=>(t.ProposalCode === v.ProposalCode))===i)
	var Cname = Obj.filter((v,i,a)=>a.findIndex(t=>(t.ClientName === v.ClientName))===i)
	var GMPNon = Obj.filter((v,i,a)=>a.findIndex(t=>(t.GMPorNonGMP === v.GMPorNonGMP))===i)
	var USDExchange = Obj.filter((v,i,a)=>a.findIndex(t=>(t.USDExchangeRate === v.USDExchangeRate))===i)
	var ReloadNew = Obj.filter((v,i,a)=>a.findIndex(t=>(t.ReloadOrNew === v.ReloadOrNew))===i)
	var BusinessUnits = Obj.filter((v,i,a)=>a.findIndex(t=>(t.BusinessUnit === v.BusinessUnit))===i)
	var CustomerCompoundCodes = Obj.filter((v,i,a)=>a.findIndex(t=>(t.CustomerCompoundCode === v.CustomerCompoundCode))===i)
	

	Fname.forEach((val, index)  => {
		FileName.push(val.FileName)
	})
	PCode.forEach((val, index)  => {
		ProposalCode.push(val.ProposalCode)
	})
	Cname.forEach((val, index)  => {
		ClientName.push(val.ClientName)
	})
	GMPNon.forEach((val, index)  => {
		GMPorNonGMP.push(val.GMPorNonGMP)
	})
	USDExchange.forEach((val, index)  => {
		USDExchangeRate.push(val.USDExchangeRate)
	})
	ReloadNew.forEach((val, index)  => {
		ReloadOrNew.push(val.ReloadOrNew)
	})
	BusinessUnits.forEach((val, index)  => {
		BusinessUnit.push(val.BusinessUnit)
	})
	CustomerCompoundCodes.forEach((val, index)  => {
		CustomerCompoundCode.push(val.CustomerCompoundCode)
	})
	
    return {FileName,ProposalCode,ClientName,GMPorNonGMP,USDExchangeRate,ReloadOrNew,BusinessUnit,CustomerCompoundCode};  
}

exports.costFilesOntime = (costSheetFiles) => {
var LeadTime = {}
			var OnTime =0
			var Delay =0
			costSheetFiles.forEach((val, index)  => {
				if(costSheetFiles.length > 0 && costSheetFiles[index].ReceievedDate && costSheetFiles[index].SubmittedDate){
					var date1 = new Date(costSheetFiles[index].ReceievedDate);
					var date2 = new Date(costSheetFiles[index].SubmittedDate);
					var diffDays = moment(date2, 'MM-DD-YYYY').businessDiff(moment(date1,'MM-DD-YYYY'));
					
					if(diffDays <= 3){
						OnTime = OnTime + 1						
					}else{
						Delay = Delay + 1
					}
				}
			})
			var OnTimePer = 0
			if(OnTime > 0){
				OnTimePer = ((OnTime/costSheetFiles.length)*100).toFixed(2);				
			}
					LeadTime['total'] =OnTime+Delay
					LeadTime['OnTime'] =OnTime
					LeadTime['Delay'] =Delay
					LeadTime['OnTimePercentage'] =OnTimePer
	return LeadTime
}

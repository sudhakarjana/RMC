'use strict';
var express = require('express');
var app = express();
var sqlDb = require("mssql");
const { default: Db } = require('mssql-async')
const db = new Db({
  user:'sa',
 password:'M0b1le@ppdb',
  server:'GVKMOBAPP', 
  database:'RMCDatabase',
  port:1433,
  ConnectionPool:50
})
var config ={
  user:'sa',
  password:'M0b1le@ppdb',
  server:'GVKMOBAPP', 
  database:'RMCDatabase',
  port:1433,
  ConnectionPool:50
}
exports.executeSqlawit = function(req, res, next) {
  var conn = new sqlDb.ConnectionPool(config)
  conn.connect()
  .then(function( ){
      var req= new sqlDb.Request(conn);
      req.query(sql,function(err,recordset){
        if (err){
			return err
        }else{
			//console.log('23',recordset)
          return recordset
        }
         
      })
  })
  .catch(function(err){
    return err;

})
}
exports.executeSql = function(sql, callback){
  var conn = new sqlDb.ConnectionPool(config)
  conn.connect()
  .then(function( ){
      var req= new sqlDb.Request(conn);
      req.query(sql,function(err,recordset){
        if (err){
			callback(err,null)
        }else{
          callback(null,recordset)
        }
         
      })
  })
  .catch(function(err){
    callback(null, err);

})
};

exports.executeSqlNewAwit = async function(sql){

  const row = await db.getrow(sql)
  console.log(row,65)
  return row	

  
};



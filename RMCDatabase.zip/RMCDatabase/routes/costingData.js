'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');
var dateFormat = require('dateformat');
var bodyParser = require('body-parser')
var jsonParser = bodyParser.json()

app.get('/all', function(req, res){
	var sql = "select * from costing ORDER BY costingId DESC;SELECT TOP 1 DateCreated FROM costing ORDER BY DateCreated DESC"
    db.executeSql(sql, function(err, recordset){
        if (err){      
            res.json({message:err,sql:sql})
        }else{
            res.json({data:recordset.recordsets[1],sql:sql});
        }       
    });
});

app.post('/all/:page', function(req, res){
	 var page = req.params.page - 1;
console.log(24,req.query)
	 var pageFor = page*10;
if(req.query && req.query.from && req.query.to){
 var where = "WHERE ProjectSubmitedDate BETWEEN '"+req.query.from+"' AND '"+req.query.to+"'"
}else{
 var where = "WHERE ProjectCode !=''"
}
	if(req.body){
		var bodyData = Object.entries(req.body).reduce((a,[k,v]) => (v ? (a[k]=v, a) : a), {})
		var pData = Object.keys(bodyData)
		var pDatas = Object.values(bodyData)
		
		if(pData.length == 1){
				if(pDatas[0].length > 0){
					let key =''
					for(let a=0; a < pDatas[0].length; a++){
						key += "'"+pDatas[0][a]+"'"
						let lastone = (pDatas[0].length) -1
						if( a < lastone){
							key +=','	
						}
					}				
					
				where = "where "+pData[0]+" in ("+key+")"
				}
		}else if(pData.length > 1){
			
			for(var i = 0; i < pData.length; i++) {
				if(pDatas[i].length >0){
					let key =''
					for(let a=0; a < pDatas[i].length; a++){
						key += "'"+pDatas[i][a]+"'"
						let lastone = (pDatas[i].length) -1
						if( a < lastone){
							key +=','	
						}
					}	
				 where  += " AND "+pData[i]+" in ("+key+")"
				}
			}
		}
		
	}
	
	var sqlQuery = "select * from costing "+where+" ORDER BY DateCreated DESC"
    db.executeSql(sqlQuery, function(err, recordset){
        if (err){
            res.json({error:true,message:err,sql:sqlQuery})
        }else{
			var pageSql = sqlQuery + " OFFSET "+pageFor+" ROWS FETCH NEXT 10 ROWS ONLY;SELECT TOP 1 DateCreated FROM costing ORDER BY DateCreated DESC"
			db.executeSql(pageSql, function(err, pageData){
				if (err){      
					res.json({error:true,message:err,pageSql:pageSql})
				}else{
					res.json({error:false,allRecords:recordset.recordsets[0].length,pagePer:10,pageNo:req.params.page,pageCount:pageData.recordset.length,data:pageData.recordset,exportExcelData:recordset.recordsets[0],lastRecord:pageData.recordsets[1]});
				}
			})
        }       
    });
	
});

app.get('/all-dropdowns', function(req, res){
		
	var sqlQuery = "select ProjectCode from costing GROUP BY ProjectCode;select FGQty from costing GROUP BY FGQty;select Material from costing GROUP BY Material;select CAS from costing GROUP BY CAS;select Qty from costing GROUP BY Qty;select UoM from costing GROUP BY UoM;select Currency from costing GROUP BY Currency;select UnitPrice from costing GROUP BY UnitPrice;select LeadTime from costing GROUP BY LeadTime;select IncoTerms from costing GROUP BY IncoTerms;select Supplier from costing GROUP BY Supplier;select Manufacturer from costing GROUP BY Manufacturer;select CountryOrState from costing GROUP BY CountryOrState;select ManuffacturingTimelines from costing GROUP BY ManuffacturingTimelines;select ContactNumber from costing GROUP BY ContactNumber;select MailId from costing GROUP BY MailId;select Remarks from costing GROUP BY Remarks;select Website from costing GROUP BY Website;select BusinessUnit from costing GROUP BY BusinessUnit;"
		
    db.executeSql(sqlQuery, function(err, recordset){
        if (err){      
            res.json({error:true,message:err,sql:sqlQuery})
        }else{
			res.json({error:false,allRecords:recordset});
        }       
    });
	
});

app.post('/create', function(req, res){
    var data = req.body;
	if(data.Material){
		var Material= data.Material.replace(/'/g,'');
	}else{
		var Material= data.Material
	}
	if(data.Supplier){
		var Supplier= data.Supplier.replace(/'/g,'');
	}else{
		var Supplier= data.Supplier
	}
	
	///var Remarks= data.Remarks.replace(/'/g,'');
	var sDate = data.ProjectSubmitedDate
    var insertSql = "INSERT INTO [costing] (ProjectSubmitedDate,ProjectCode,FGQty,Material,CAS,Qty,UoM,Currency,UnitPrice,LeadTime,IncoTerms,Supplier,Manufacturer,CountryOrState,ManuffacturingTimelines,ContactNumber,MailId,Remarks,Website,BusinessUnit) VALUES"
    insertSql += util.format("('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",
    data.ProjectSubmitedDate?data.ProjectSubmitedDate:'',data.ProjectCode?data.ProjectCode:'',data.FGQty?data.FGQty:'',Material?Material:'',data.CAS?data.CAS:'',data.Qty?data.Qty:'',data.UoM?data.UoM:'',data.Currency?data.Currency:'',data.UnitPrice?data.UnitPrice:'',data.LeadTime?data.LeadTime:'',data.IncoTerms?data.IncoTerms:'',Supplier?Supplier:'',data.Manufacturer?data.Manufacturer:'',data.CountryOrState?data.CountryOrState:'',data.ManuffacturingTimelines?data.ManuffacturingTimelines:'',data.ContactNumber?data.ContactNumber:'',data.MailId?data.MailId:'',data.Remarks?data.Remarks:'',data.Website?data.Website:'',data.BusinessUnit?data.BusinessUnit:'')
    db.executeSql(insertSql, function(err, recordset){
        if (err){      
			console.log('insertSql',insertSql)
            res.status(200).json({message:err,insertSql:insertSql})
        }else{
            res.json({data:recordset.recordset});
        }       
    });
});
// single record
app.get('/getbyid/:id',(req, res) => {
    let sql = "SELECT * FROM costing WHERE costingId ="+req.params.id;
    db.executeSql(sql, (err, results) => {
        if (err){      
            res.status(500).json({message:err,sql:sql})
        }else{
            res.json({data:results.recordset});
        }
    });
  });
// update row

app.put('/updateDetails/:id', function(req, res){
    var data  = req.body;
    var id = req.params.id;
    var updateValue =''
    var ProjectSubmitedDate = data.ProjectSubmitedDate?data.ProjectSubmitedDate:''
    var ProjectCode = data.ProjectCode?data.ProjectCode:''
    var FGQty = data.FGQty?data.FGQty:''
    var Material = data.Material?data.Material:''
    var CAS = data.CAS?data.CAS:''
    var Qty = data.Qty?data.Qty:''
    var UoM = data.UoM?data.UoM:''
    var Currency = data.Currency?data.Currency:''
    var UnitPrice = data.UnitPrice?data.UnitPrice:''
    var LeadTime = data.LeadTime?data.LeadTime:''
    var IncoTerms = data.IncoTerms?data.IncoTerms:''
    var Supplier = data.Supplier?data.Supplier:''
    var Manufacturer = data.Manufacturer?data.Manufacturer:''
    var CountryOrState = data.CountryOrState?data.CountryOrState:''
    var ManuffacturingTimelines = data.ManuffacturingTimelines?data.ManuffacturingTimelines:''
    var ContactNumber = data.ContactNumber?data.ContactNumber:''
    var MailId = data.MailId?data.MailId:''
    var Remarks = data.Remarks?data.Remarks:''
    var Website = data.Website?data.Website:''
		
    var sql = "UPDATE costing SET ProjectSubmitedDate='" +ProjectSubmitedDate+"',ProjectCode='" +ProjectCode+"', FGQty='" +FGQty+"', Material='" +Material+"', CAS='" +CAS+"', Qty='" +Qty+"', UoM='" +UoM+"' , Currency='" +Currency+"' , UnitPrice='" +UnitPrice+"', LeadTime='" +LeadTime+"', IncoTerms='" +IncoTerms+"', Supplier='" +Supplier+"', Manufacturer='" +Manufacturer+"', CountryOrState='" +CountryOrState+"', ManuffacturingTimelines='" +ManuffacturingTimelines+"', ContactNumber='" +ContactNumber+"', MailId='" +MailId+"', Remarks='" +Remarks+"', Website='" +Website+"' where costingId ="+id
    console.log(sql)
    db.executeSql(sql, function(err, recordset){
        if (err){      
            res.status(500).json({message:err,sql:sql})
        }else{
            res.json({data:recordset,sql:sql});
        }
    })
})

/// DELETE Row in Import Shipment

app.delete('/remove/:id', function(req, res){
    console.log('connection established')
    const id = req.params.id;
    console.log("ID ID", id)
    var sql = "DELETE FROM costing WHERE costingId IN ("+id+");";
    db.executeSql(sql, function(err, recordset){
        if (err){       
			res.json({error:true,sql:sql})
        } else { 
			res.json({error:false,result:recordset,params:req.body})
		}
    });
})
app.post('/remove-multi/', function(req, res){
    const id = req.body.ids;
    var sql = "DELETE FROM costing WHERE costingId IN ("+id+");";
    db.executeSql(sql, function(err, recordset){
        if (err){       
			res.json({error:true,sql:sql})
        } else { 
			res.json({error:false,result:recordset,params:req.body})
		}
    });
})
app.post('/removeAll', function(req, res){
    console.log('connection established')
    const id = req.params.id;
    console.log("ID ID", id)
    var sql = "DELETE FROM costing";
    console.log("query",sql)
    db.executeSql(sql, function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         res.send(recordset)
    });
})

module.exports = app;
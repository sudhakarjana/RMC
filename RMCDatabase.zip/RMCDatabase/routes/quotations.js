'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');
var fs = require('fs');
var dateFormat = require('dateformat');
const readXlsxFile = require('read-excel-file/node');
const multer = require('multer');
var moment = require('moment-business-days');
const config = require("../info/index");
const { getJsDateFromExcel } = require("excel-date-to-js");
const { Validator } = require('node-input-validator');

var listHolday = ['01-01-2021','14-01-2021','26-01-2021','02-04-2021','13-04-2021','21-04-2021','01-05-2021','14-05-2021','10-09-2021','15-10-2021','04-11-2021'] 
moment.updateLocale('us', {
   holidays: listHolday,
   holidayFormat: 'DD-MM-YYYY'
});
moment.updateLocale('us', {
   workingWeekdays: [1, 2, 3, 4, 5]
});

const PATH = './files';

let storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, PATH);
  },
  filename: (req, file, cb) => {
	let extArray = file.originalname.split(".");   
    let extension = extArray[extArray.length - 1];
    let fileName = extArray[0].replace(' ','-');
    cb(null, fileName + '-' + Date.now()+ '.' +extension)
	
  }
});

let upload = multer({
  storage: storage
});

function isFloat(x) { return !!(x % 1); }
function parseFloatConvert(r) {
  if (Number.isNaN(Number.parseFloat(r))) {
    return 0;
  }
  return parseFloat(r) ;
}
 function getXlsxDataValidate(file){
	 return new Promise(async resolve => {
	const rawData = await readXlsxFile(file, { getSheets: true }).then((names) => {return names  })
	let paymentsData = [];
		rawData.forEach(async (item, idx) => {
			let data = await readXlsxFile(file, { sheet: idx+1 }).then((dataOne) => {return dataOne })
			var ReceievedDate =data[0][1]
			var SubmittedDate =data[6][1]
				if(typeof(SubmittedDate) === 'number'){
						var SubmittedDatedtNew=dateFormat(getJsDateFromExcel(SubmittedDate), "dd-mm-yyyy");
				}else{
						var SubmittedDatedtNew=SubmittedDate
				}
				
				if(typeof(ReceievedDate) === 'number'){					
						var ReceievedDatedtNew=dateFormat(getJsDateFromExcel(ReceievedDate), "dd-mm-yyyy");
				}else{
						var ReceievedDatedtNew=ReceievedDate
				}
			
				  var post  = {
							ReceievedDate:ReceievedDatedtNew,
							ClientName:data[1][1],
							ProposalCode:data[2][1],
							USDExchangeRate:data[3][1],
							CustomerCompoundCode:data[4][1],
							BusinessUnit:data[5][1],
							SubmittedDate:SubmittedDatedtNew,
							GMPorNonGMP:data[7][1],
							ReloadOrNew:data[8][1],
							TotalRMC:data[9][1],
							LeadTime:data[10][1],
							FGQty:data[11][1]
						}
				const v = new Validator(post, {
							ReceievedDate: 'required|dateFormat:DD-MM-YYYY',
							ClientName: 'required',
							ProposalCode: 'required',
							USDExchangeRate: 'required',
							CustomerCompoundCode: 'required',
							BusinessUnit: 'required',
							SubmittedDate: 'required|dateFormat:DD-MM-YYYY',
							GMPorNonGMP: 'required|in:Non-GMP,GMP',
							ReloadOrNew: 'required|in:Reload,New',
							TotalRMC: 'required',
							LeadTime: 'required|in:true,false',
							FGQty: 'required'
					  });				
				v.check().then((matched) => {
					if(!matched){
						paymentsData[idx] = {sheet:idx+1,err:v.errors}
					}
					if(idx+1 === rawData.length){
							 resolve(paymentsData);
						}
				})
				
				
		})
		
  });

}

app.post('/create-validate',  upload.single('csvfile') ,async function(req, res){
		var file = 'files/'+req.file.filename;
	const ret = await getXlsxDataValidate(file)
	res.json(ret)
	  
})

app.get('/all', function(req, res){
  
 //   let sql = "SELECT quotationId,quantity, Count(*) as count FROM quotations Group By quotationId, quantity"
    let sql = "SELECT * FROM costSheets order by costSheet_id DESC;SELECT TOP 1 createdDate FROM costSheets ORDER BY createdDate DESC"
    db.executeSql(sql, (err, results) => {
        if (err){      
		    res.status(500).json({message:err,sql:sql})
        }else{
            res.json({count:results.recordset.length,data:results.recordset,lastRecord:results.recordsets[1]});
        }
    });
});

app.get('/cost-dropdowns', function(req, res){
		
	var sqlQuery = "select ClientName from costSheets GROUP BY ClientName;select ProposalCode from costSheets GROUP BY ProposalCode;;select USDExchangeRate from costSheets GROUP BY USDExchangeRate;select CustomerCompoundCode from costSheets GROUP BY CustomerCompoundCode;select GMPorNonGMP from costSheets GROUP BY GMPorNonGMP;select BusinessUnit from costSheets GROUP BY BusinessUnit;select quantity from costSheets GROUP BY quantity;select ReloadOrNew from costSheets GROUP BY ReloadOrNew;select TotalRMC from costSheets GROUP BY TotalRMC;select LeadTime from costSheets GROUP BY LeadTime;select FGQty from costSheets GROUP BY FGQty;"
		
    db.executeSql(sqlQuery, function(err, recordset){
        if (err){      
            res.json({error:true,message:err,sql:sqlQuery})
        }else{
			res.json({error:false,allRecords:recordset});
        }       
    });
    });
app.get('/cost-files-dropdowns', function(req, res){
		
	var sqlQuery = "select ClientName from costSheetFiles GROUP BY ClientName;select ProposalCode from costSheetFiles GROUP BY ProposalCode;;select USDExchangeRate from costSheetFiles GROUP BY USDExchangeRate;select CustomerCompoundCode from costSheetFiles GROUP BY CustomerCompoundCode;select GMPorNonGMP from costSheetFiles GROUP BY GMPorNonGMP;select BusinessUnit from costSheetFiles GROUP BY BusinessUnit;select ReloadOrNew from costSheetFiles GROUP BY ReloadOrNew;select FileName from costSheetFiles GROUP BY FileName;"
		
    db.executeSql(sqlQuery, function(err, recordset){
        if (err){      
            res.json({error:true,message:err,sql:sqlQuery})
        }else{
			res.json({error:false,allRecords:recordset});
        }       
    });
    });
	
	
app.post('/all/:FileId/:page/:pageFor', function(req, res){
	 var FileId = req.params.FileId;
	 var page = req.params.page - 1;
	 var pageFor = req.params.pageFor;
	 var offSet = page*pageFor;
	var where="WHERE FileId ="+FileId
	if(req.body){
		var bodyData = Object.entries(req.body).reduce((a,[k,v]) => (v ? (a[k]=v, a) : a), {})
		var pData = Object.keys(bodyData)
		var pDatas = Object.values(bodyData)
		
		if(pData.length == 1){
				if(pDatas[0].length > 0){
					let key =''
					for(let a=0; a < pDatas[0].length; a++){
						key += "'"+pDatas[0][a]+"'"
						let lastone = (pDatas[0].length) -1
						if( a < lastone){
							key +=','	
						}
					}				
					
				where = "where FileId ="+FileId+" AND "+pData[0]+" in ("+key+")"
				}
		}else if(pData.length > 1){
			where = "WHERE FileId ="+FileId
			
			for(var i = 0; i < pData.length; i++) {
				if(pDatas[i].length >0){
					let key =''
					for(let a=0; a < pDatas[i].length; a++){
						key += "'"+pDatas[i][a]+"'"
						let lastone = (pDatas[i].length) -1
						if( a < lastone){
							key +=','	
						}
					}	
				 where  += " AND "+pData[i]+" in ("+key+")"
				}
			}
		}
		
	}
	
	var sqlQuery = "select * from costSheets "+where+" ORDER BY createdDate DESC"
		
    db.executeSql(sqlQuery, function(err, recordset){
        if (err){
            res.json({error:true,message:err,sql:sqlQuery})
        }else{
			console.log(149,sqlQuery)
			var pageSql = sqlQuery + " OFFSET "+offSet+" ROWS FETCH NEXT "+pageFor+" ROWS ONLY;SELECT TOP 1 createdDate FROM costSheets ORDER BY createdDate DESC"
			db.executeSql(pageSql, function(err, pageData){
				if (err){      
					res.json({error:true,message:err,pageSql:pageSql})
				}else{
					res.json({error:false,allRecords:recordset.recordsets[0].length,pagePer:pageFor,pageNo:req.params.page,pageCount:pageData.recordset.length,data:pageData.recordset,exportExcelData:recordset.recordsets[0],lastRecord:pageData.recordsets[1]});
				}
			})
        }       
    });
	
});

app.post('/all-costsheet-files/:page/:pageFor', function(req, res){
	 var page = req.params.page - 1;
	 var pageFor = req.params.pageFor;
	 var offSet = page*pageFor;
	var where=''
	if(req.body){
		if(req.query.from && req.query.to){
				var toDate =req.query.to+' 23:59:59.99';
				var where="WHERE SubmittedDate BETWEEN '"+req.query.from+"' AND '"+toDate+"'"
			}else{
				var where=""
			}
		var bodyData = Object.entries(req.body).reduce((a,[k,v]) => (v ? (a[k]=v, a) : a), {})
		var pData = Object.keys(bodyData)
		var pDatas = Object.values(bodyData)
		
		if(pData.length == 1){
				if(pDatas[0].length > 0){
					let key =''
					for(let a=0; a < pDatas[0].length; a++){
						key += "'"+pDatas[0][a]+"'"
						let lastone = (pDatas[0].length) -1
						if( a < lastone){
							key +=','	
						}
					}				
					
				where = "where "+pData[0]+" in ("+key+")"
				}
		}else if(pData.length > 1){
			where = "WHERE ProposalCode !=''"
			
			for(var i = 0; i < pData.length; i++) {
				if(pDatas[i].length >0){
					let key =''
					for(let a=0; a < pDatas[i].length; a++){
						key += "'"+pDatas[i][a]+"'"
						let lastone = (pDatas[i].length) -1
						if( a < lastone){
							key +=','	
						}
					}	
				 where  += " AND "+pData[i]+" in ("+key+")"
				}
			}
		}
		
	}
	
	var sqlQuery = "select * from costSheetFiles "+where+" ORDER BY createdDate DESC"
		
    db.executeSql(sqlQuery, function(err, recordset){
        if (err){
            res.json({error:true,message:err,sql:sqlQuery})
        }else{
			var pageSql = sqlQuery + " OFFSET "+offSet+" ROWS FETCH NEXT "+pageFor+" ROWS ONLY;SELECT TOP 1 createdDate FROM costSheetFiles ORDER BY createdDate DESC"
			db.executeSql(pageSql, function(err, pageData){
				if (err){      
					res.json({error:true,message:err,pageSql:pageSql})
				}else{
//				console.log(recordset,2188)
					
								var allRecords = recordset.recordsets[0]
								var costFilesdropDowns = config.costFilesdropDowns(allRecords)
					res.json({error:false,allRecords:recordset.recordsets[0].length,pagePer:pageFor,pageNo:req.params.page,pageCount:pageData.recordset.length,data:pageData.recordset,exportExcelData:recordset.recordsets[0],lastRecord:pageData.recordsets[1],costFilesdropDowns:costFilesdropDowns});
				}
			})
        }       
    });
	
});


app.post('/datenum',  function(req, res){
		var SubmittedDatedtNew=dateFormat(getJsDateFromExcel(req.body.SubmittedDate), "yyyy-mm-dd");
res.json({error:true,message:SubmittedDatedtNew})
})

app.post('/create', upload.single('csvfile') ,async function(req, res){

    if(req.file){
    var file = 'files/'+req.file.filename;
	const errResponse = await getXlsxDataValidate(file)
	if(errResponse.length > 0){
		fs.unlinkSync(file);
		res.status(400).json({error:true,response:errResponse, message:"Send all required fields"});	
		return
	}
    readXlsxFile(file, { getSheets: true }).then((names) => {
        var k = 0
	readXlsxFile(file, { sheet: 1 }).then((dataOne) => {
		   
		        var ReceievedDate = dataOne[0][1]
				var ClientName = dataOne[1][1]
				var ProposalCode = dataOne[2][1]
				var USDExchangeRate = dataOne[3][1]
				var CustomerCompoundCode = dataOne[4][1]
				var BusinessUnit = dataOne[5][1]
				var SubmittedDate = dataOne[6][1]
				var GMPorNonGMP = dataOne[7][1]
				var ReloadOrNew = dataOne[8][1]
				var TotalRMC = dataOne[9][1]
				var LeadTime = dataOne[10][1]
				var FGQty = dataOne[11][1]
				var FileName= req.file.originalname
if(ReceievedDate && ProposalCode && SubmittedDate && GMPorNonGMP && ReloadOrNew && TotalRMC){
			
if(typeof(SubmittedDate) === 'number')
{
	
		var SubmittedDatedtNew=dateFormat(getJsDateFromExcel(SubmittedDate), "yyyy-mm-dd");

}else{
		var SubmittedDatedt = new Date(SubmittedDate).toISOString('en-US', {  timeZone: 'Asia/Calcutta'})
		var SubmittedDatedtNew=dateFormat(SubmittedDatedt, "yyyy-mm-dd");

}
if(typeof(ReceievedDate) === 'number'){
	
		var ReceievedDatedtNew=dateFormat(getJsDateFromExcel(ReceievedDate), "yyyy-mm-dd");

}else{
		var ReceievedDatedt = new Date(ReceievedDate).toISOString('en-US', {  timeZone: 'Asia/Calcutta'})
		var ReceievedDatedtNew=dateFormat(ReceievedDatedt, "yyyy-mm-dd");


}
console.log(SubmittedDatedt,SubmittedDate)
		var selectQuery = "INSERT INTO [costSheetFiles] (ClientName,ProposalCode,USDExchangeRate,CustomerCompoundCode,BusinessUnit,SubmittedDate,GMPorNonGMP,FileName,ReceievedDate,ReloadOrNew) VALUES('"+ClientName+"','"+ProposalCode+"','"+USDExchangeRate+"','"+CustomerCompoundCode+"','"+BusinessUnit+"','"+SubmittedDatedtNew+"','"+GMPorNonGMP+"','"+FileName+"','"+ReceievedDatedtNew+"','"+ReloadOrNew+"');SELECT SCOPE_IDENTITY() AS FileId";
			   
	db.executeSql(selectQuery, function(errSlect, responseSelect){
		if(!errSlect){
		
			console.log(selectQuery,responseSelect)
			console.log(responseSelect.recordset[0].FileId,263)
			//var FileidValue = Object.values(responseSelect.recordsets[0][0])
			var Fileid = responseSelect.recordset[0].FileId

			
    for (let i = 0; i < names.length; i++) {
	   var e =0
	   var insertss = {};     
       var read = readXlsxFile(file, { sheet: i+1 }).then((data) => {
		   
		        var ReceievedDate = data[0][1]
				var ClientName = data[1][1]
				var ProposalCode = data[2][1]
				var USDExchangeRate = data[3][1]
				var CustomerCompoundCode = data[4][1]
				var BusinessUnit = data[5][1]
				var SubmittedDate = data[6][1]
				var GMPorNonGMP = data[7][1]
				var ReloadOrNew = data[8][1]
				var TotalRMC = data[9][1]
				var LeadTime = data[10][1]
				var FGQty = data[11][1]
				var quantity= names[i].name
				var FileName= req.file.originalname
		   
		   if(ReceievedDate && ProposalCode && SubmittedDate && GMPorNonGMP && ReloadOrNew){
			   
			   
	var selectQuery = "SELECT IDENT_CURRENT('costSheetFiles');"		  
			   
	
	


		var insertCostSheetSql = "INSERT INTO [costSheets] (ClientName,ProposalCode,USDExchangeRate,CustomerCompoundCode,BusinessUnit,SubmittedDate,GMPorNonGMP,quantity,ReceievedDate,ReloadOrNew,TotalRMC,LeadTime,FGQty,FileId) VALUES('"+ClientName+"','"+ProposalCode+"','"+USDExchangeRate+"','"+CustomerCompoundCode+"','"+BusinessUnit+"','"+SubmittedDatedtNew+"','"+GMPorNonGMP+"','"+quantity+"','"+ReceievedDatedtNew+"','"+ReloadOrNew+"','"+TotalRMC+"','"+LeadTime+"','"+FGQty+"',"+Fileid+")";

		insertCostSheetSql+= "SELECT SCOPE_IDENTITY() AS id";

				
		db.executeSql(insertCostSheetSql, function(err, response){
				
				if (err){ 
				  res.json({error:true,err:err});
				}else{
		   
        var insertSql = "INSERT INTO [quotations] (quotationId,quantity,Stage,SNo,Name,CAS_Number,Input,Rec,Con,Output,Unit,Density,Mol_Wt,Mol_Eq_Vol,Actual_Yield,Reported_Yields,Unit_Cost_Per_Kg_Rs,Con_CC_in_Kg,Total_Cost_Rs,Percentage_of_the_total_cost,Quality,Source,Lead_time,Min_pack,MadeOfShipment,Remarks,Chemical_category,Received,ClientName,ProposalCode,USDExchangeRate,CustomerCompoundCode,BusinessUnit,SubmittedDate,GMPorNonGMP,ReloadOrNew,costSheet_id,Country,StageCat,TotalRMC,LeadTime,FGQty,Fileid) VALUES"
           
				
		
		   for (let index = 13; index < data.length; index++) {
				const element = data[index];
            	var quotationId= 1
                var Stage= element[0]
				var SNo= element[1]
				var Name= element[2]
				var CAS_Number= element[3]
				var Input= element[4]
				var Rec	= element[5]
				var Con	= element[6]
				var Output	= element[7]
				var Unit = element[8]
				var Density = element[9]
				var Mol_Wt = element[10]
				var Mol_Eq_Vol = element[11]
				var Actual_Yield = element[12]
				var Reported_Yields = element[13]
				var Unit_Cost_Per_Kg_Rs = element[14]
				var Con_CC_in_Kg = element[15]
				var Total_Cost_Rs = element[16]
				var Percentage_of_the_total_cost = parseFloatConvert(element[17])
				var Quality = element[18]
				var Source = element[19]
				if(isNaN(element[20])){
					var Lead_time =''
				}else{
					var Lead_time = element[20]
				}
				
				var Min_pack = element[21]
				var MadeOfShipment = element[22]
				var Remark = element[23]
				if (Remark !== null && Remark !==undefined && !isFloat && Remark) {
                        var Remarks = Remark.replace(/[,.'"]/g , '');
				} else {
					var Remarks = '';
				}
				var Chemical_category = element[24]               
				var Country = element[25]               
				var KRM = element[26]               
				var costSheet_id = response.recordset[0].id      
				var GMPorNonGMPValue = GMPorNonGMP
				var quantityValue = quantity
				if(element[0] == 'Total RM cost' || element[0] == 'LR Misc' || element[0] == 'Cleaning solvents' || element[0] == 'Final RMC in INR' || element[0] == ''|| element[0] == null || element[0] == 'Stage'){
		//			console.log(element[0])
				}else{
					//console.log(element[0])
					insertSql += util.format("('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",
					quotationId?quotationId:'',quantity?quantity:'',Stage?Stage:'',SNo?SNo:'',Name?Name:'',CAS_Number?CAS_Number:'',Input?Input:'',Rec?Rec:'',Con?Con:'',Output?Output:'',Unit?Unit:'',Density?Density:'',Mol_Wt?Mol_Wt:'',Mol_Eq_Vol?Mol_Eq_Vol:'',Actual_Yield?Actual_Yield:'',Reported_Yields?Reported_Yields:'',Unit_Cost_Per_Kg_Rs?Unit_Cost_Per_Kg_Rs:'',Con_CC_in_Kg?Con_CC_in_Kg:'',Total_Cost_Rs?Total_Cost_Rs:'',Percentage_of_the_total_cost?Percentage_of_the_total_cost:'',Quality?Quality:'',Source?Source:'',Lead_time?Lead_time:'',Min_pack?Min_pack:'',MadeOfShipment?MadeOfShipment:'',Remarks?Remarks:'',Chemical_category?Chemical_category:'',ReceievedDatedtNew?ReceievedDatedtNew:'',ClientName?ClientName:'',ProposalCode?ProposalCode:'',USDExchangeRate?USDExchangeRate:'',CustomerCompoundCode?CustomerCompoundCode:'',BusinessUnit?BusinessUnit:'',SubmittedDatedtNew?SubmittedDatedtNew:'',GMPorNonGMPValue?GMPorNonGMPValue:'',ReloadOrNew?ReloadOrNew:'',costSheet_id?costSheet_id:'',Country?Country:'',KRM?KRM:0,TotalRMC?TotalRMC:'',LeadTime?LeadTime:'false',FGQty?FGQty:'',Fileid?Fileid:'')
				}
                
				let lastone = (data.length) - 2
				if( index < lastone){
					if(element[0] == 'Total RM cost' || element[0] == 'Total RMC' || element[0] == 'LR Misc' || element[0] == 'Cleaning solvents' || element[0] == 'Final RMC in INR' || element[0] == ''|| element[0] == null || element[0] == 'Stage'){
				//	console.log(element[0])
					}else{
						insertSql +=','
					}
                }
				
                
            }
            var qty = names[i].name
            if(insertSql.endsWith(",")) {
			  insertSql = insertSql.slice(0,-1);
			}
            db.executeSql(insertSql, function(err, recordset){
                if (err){   
				console.log(insertSql)
					db.executeSql("DELETE FROM costSheets WHERE costSheet_id IN ("+costSheet_id+")", function(deleteErr, desleteRecord){
						 if (deleteErr){
							 console.log(deleteErr,"DELETE FROM costSheets WHERE costSheet_id IN ("+costSheet_id+")")
						 }else{
							 console.log("delete success")
						 }
					})
				   k ++
                   insertss[qty]='Uploading Failed';
                   if(k == names.length){
					   fs.unlinkSync(file);
                      res.json({error:true,response:insertss,insertSql:insertSql});
                   }
                }else{
						k ++
                    if(recordset.rowsAffected){
                        insertss[qty]= recordset.rowsAffected +' Successfully created';                       
                    }else{
                        insertss[qty]= 'No records found'
                    }
                    if(k == names.length){
						fs.unlinkSync(file);
                       res.json({error:false,response:insertss});
                    }
                   
                }   
                

            });
			}
			
            });
			
			
		
	   }else{
		   res.json({error:true,message:"Send all required fields"});
	   }
            
        })
    }
             
			 
			 
		}else{
			console.log(selectQuery,451)
			 res.json({error:true,message:"Please Valid file"});
		}
	})
	}else{
		   res.json({error:true,message:"Send all required fields"});
	   }
	})
	

    })

}else{
    res.status(400).json({message:"Some fields are missing",data:req.body.csvfile,file:req.file});
}
    
 
    
});
// single record
app.get('/getbyid/:quotationId',(req, res) => {
    console.log(req.params)
    let sql = "SELECT * FROM quotations WHERE costSheet_id ='"+req.params.quotationId+"'"
    db.executeSql(sql, (err, results) => {
        if (err){      
            res.status(500).json({message:err,sql:sql})
        }else{
            res.json({count:results.recordset.length,data:results.recordset});
        }
    });
  });
app.post('/getby-costsheet-code/',(req, res) => {
	console.log(req.body)
   if(req.body.CostsheetCode){
	   
	   
	   
    let sql = "SELECT costSheets.TotalRMC as cTotalRMC,costSheets.costSheet_id as Uniq,costSheets.ProposalCode as costSheet_code, quotations.* FROM costSheets LEFT JOIN quotations ON quotations.costSheet_id = costSheets.costSheet_id WHERE costSheets.ProposalCode ='"+req.body.CostsheetCode+"'; select * from costSheets WHERE ProposalCode ='"+req.body.CostsheetCode+"'"
    db.executeSql(sql, (err, results) => {
        if (err){      
	        res.status(500).json({message:err,sql:sql})
        }else{		
			var costSheetDetails = results.recordsets[0]
			var costSheetDetail = results.recordsets[1]
			var report = []
			results.recordsets[1].forEach((val, index)  => {
				
				var individval = {}
				var detail =costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id && item.SNo != ''))
				if(detail.length >0){
					individval['CostsheetCode'] = detail[0].ProposalCode
					individval['GMPorNonGMP'] = detail[0].GMPorNonGMP
					individval['RFPRceievedDate'] = detail[0].Received
					individval['RFPSubmittedDate'] = detail[0].SubmittedDate
					individval['FGQtyINKG'] = detail[0].quantity
					individval['NoOfProjectSpecificChemicals'] = costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id && item.SNo != '' && (item.Chemical_category).toLowerCase() == 'project specific')).length
					individval['NoOfKRMsCritical'] = "Pending"
					
					var date1 = new Date(detail[0].Received);
					var date2 = new Date(detail[0].SubmittedDate);
					var diffDays = date2.getDate() - date1.getDate();
					individval['TAT'] = diffDays
					if(diffDays <= 3){
						var TATStatus = 'On Time'
					}else{
						var TATStatus = 'Delay'
					}
					individval['TATStatus'] = TATStatus
					
					individval['NoofRMsGreaterWeeks'] = detail.filter(item => (item.costSheet_id === val.costSheet_id && item.Lead_time >= 5 && item.SNo != '')).length

					individval['MaxCostContribution'] = Math.max.apply(Math, detail.map(function(o) { return o.Percentage_of_the_total_cost; }))
					individval['MaxLeadTimeinWeeks'] = Math.max.apply(Math, detail.map(function(o) { return o.Lead_time; }))
					var Lead_timeMax = Math.max.apply(Math, detail.map(function(o) { return o.Lead_time; }))
					var PercentagcostMax = Math.max.apply(Math, detail.map(function(o) { return o.Percentage_of_the_total_cost; }))
				
					var maxCostObject = detail.find(o => o.Percentage_of_the_total_cost == PercentagcostMax);
					var maxLeadObject = detail.find(o => o.Lead_time == Lead_timeMax);
					var maxLeadTime = detail.filter(o => o.Lead_time != '');
					
					let popularitySum = 0;
					let itemsFound = 0;
					const len = maxLeadTime.length;
					let item = null;
					for (let i = 0; i < len; i++) {
						item = maxLeadTime[i];
						if (item.Lead_time) {
							popularitySum = parseInt(item.Lead_time) + popularitySum;
							itemsFound = itemsFound + 1;
						
						}
					}
					var averagePopularity = 0

					if(itemsFound > 0){
						 averagePopularity = popularitySum / itemsFound;
					}
					console.log(popularitySum,itemsFound)
					var details =costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id))
					
					var TotalcostFromChaina =0
					var materialsQuotedFromChina =costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id && item.Country ==='China'))
					materialsQuotedFromChina.forEach(valueM => {
						TotalcostFromChaina = TotalcostFromChaina + parseFloat(valueM.Total_Cost_Rs)
					})
					individval['HighLeadtimeMaterial'] = maxLeadObject.Name
					individval['HighCostContributor'] = maxCostObject.Name
					individval['ConsideredVendorCostContributor'] = maxCostObject.Source
					individval['AverageLeadTime'] = averagePopularity
					individval['materialsQuotedFromChina'] = materialsQuotedFromChina.length
					individval['ChinaRMvalue'] = TotalcostFromChaina
					individval['TotalRMC'] = costSheetDetail[index].TotalRMC
					//individval['cTotalRMC'] = costSheetDetail[index].cTotalRMC
					
					report.push(individval)
				}
			})
			
			
            res.json({error:false,count:results.recordsets[1].length,report:report});
        }
    });
   }else{
	   res.json({error:true,message:"Send required fields"});
   }
  });
  app.post('/getby-cas-code/:page',(req, res) => {
	 var page = req.params.page - 1;
	 var limit = 10
	 var pageFor = page*limit;
	if(req.body){
			if(req.query.from && req.query.to){
						  var toDate =req.query.to+' 23:59:59.99';	

				var where="WHERE SubmittedDate BETWEEN '"+req.query.from+"' AND '"+toDate+"' AND LeadTime LIKE 'true'"
			}else{
				var where="WHERE LeadTime LIKE 'true'"
			}				
		var bodyData = Object.entries(req.body).reduce((a,[k,v]) => (v ? (a[k]=v, a) : a), {})
		var pData = Object.keys(bodyData)
		var pDatas = Object.values(bodyData)
		
		if(pData.length == 1){
				if(pDatas[0].length > 0){
					let key =''
					for(let a=0; a < pDatas[0].length; a++){
						key += "'"+pDatas[0][a]+"'"
						let lastone = (pDatas[0].length) -1
						if( a < lastone){
							key +=','	
						}
					}				
					
				where += " AND "+pData[0]+" in ("+key+")"
				}
		}else if(pData.length > 1){
			for(var i = 0; i < pData.length; i++) {
				if(pDatas[i].length >0){
					let key =''
					for(let a=0; a < pDatas[i].length; a++){
						key += "'"+pDatas[i][a]+"'"
						let lastone = (pDatas[i].length) -1
						if( a < lastone){
							key +=','	
						}
					}	
				 where  += " AND "+pData[i]+" in ("+key+")"
				}
			}
		}
		
    let sql = "select * from quotations "+where+" ORDER BY Percentage_of_the_total_cost DESC;select * from quotations "+where+" ORDER BY Percentage_of_the_total_cost DESC OFFSET "+pageFor+" ROWS FETCH NEXT "+limit+" ROWS ONLY"
	db.executeSql(sql, (err, results) => {
        if (err){      
            res.status(500).json({message:err,sql:sql})
        }else{		
			var costSheetDetails = results.recordsets[1]
			var TotalcostFromChaina = 0
			var materialsQuotedFromChina =costSheetDetails.filter(item => (item.LeadTime ==='true'))
			materialsQuotedFromChina.forEach(valueM => {
				if(parseFloat(valueM.Total_Cost_Rs)){
					TotalcostFromChaina = TotalcostFromChaina + parseFloat(valueM.Total_Cost_Rs)
				}
				})
			var avg = TotalcostFromChaina /	costSheetDetails.length
			var allRecords = results.recordsets[0]
			var dropDowns = config.dropDowns(allRecords)

			res.json({error:false,dropDowns:dropDowns,count:results.recordset.length,allRecords:allRecords,page:req.params.page,pagePer:limit,report:costSheetDetails,avg:avg});
        }
    });
   }else{
	   res.json({error:true,message:"Send required fields"});
   }
  });  
  
app.post('/getby-name/',(req, res) => {
	console.log(req.body)
   if(req.body.name){
	   
    let sql = "select * from quotations WHERE Name LIKE '%"+req.body.name+"%'"
    db.executeSql(sql, (err, results) => {
        if (err){      
			console.log(err, sql)
            res.status(500).json({message:err,sql:sql})
        }else{		
			var costSheetDetails = results.recordset
		    res.json({error:false,count:results.recordset.length,report:costSheetDetails});
        }
    });
   }else{
	   res.json({error:true,message:"Send required fields"});
   }
  });
  app.post('/getby-date/',(req, res) => {
    console.log(req.params)
	var data = req.body;
	if(data.fromDate && data.toDate){
		  var toDate =data.toDate+' 23:59:59.99';	
	let sql = "SELECT costSheets.costSheet_id as Uniq,costSheets.ProposalCode as costSheet_code, quotations.* FROM costSheets LEFT JOIN quotations ON quotations.costSheet_id = costSheets.costSheet_id Where costSheets.SubmittedDate BETWEEN '"+data.fromDate+"' AND '"+toDate+"' AND costSheets.LeadTime='true'; select * from costSheets WHERE SubmittedDate BETWEEN '"+data.fromDate+"' AND '"+toDate+"' AND LeadTime='true'; select * from costSheetFiles WHERE SubmittedDate BETWEEN '"+data.fromDate+"' AND '"+toDate+"'"
    db.executeSql(sql, (err, results) => {
        if (err){      
            res.status(500).json({message:err,sql:sql})
        }else{		
			var costSheetDetails = results.recordsets[0]
			var LeadTime = {}
			var avgLeadTimeByCostsheet = 0
			var avgLeadTimeLessFiftyFGQty = 0
			var RFPwithTotalRMC = 0
			var chemicals = 0 
			var chemicalsPer = 0 
			var chemicalsPerCon = 0 
			var NoOFRFPswithlessthan50kgFGQty = 0 
			var NoOFRFPswithGreterthan50kgFGQty = 0 
			var avgLess50FGCount = 0 
			var avgLeadAbove5Weeks = 0 
			var NoRMweeksLeadtime = 0 
			var TotalNoRMsfromChina = 0 
			var NoRFSweeksLeadtime = 0 
			var TotalcostFromChaina = 0
			var Delay = 0
			var OnTime = 0
			var costSheetFiles =results.recordsets[2]
			costSheetFiles.forEach((val, index)  => {
				if(costSheetFiles.length > 0 && costSheetFiles[index].ReceievedDate && costSheetFiles[index].SubmittedDate){
					var date1 = new Date(costSheetFiles[index].ReceievedDate);
					var date2 = new Date(costSheetFiles[index].SubmittedDate);
					var diffDays = moment(date2, 'MM-DD-YYYY').businessDiff(moment(date1,'MM-DD-YYYY'));
					
					if(diffDays <= 3){
						OnTime = OnTime + 1						
					}else{
						Delay = Delay + 1
					}
					LeadTime['OnTime'] =OnTime
					LeadTime['Delay'] =Delay
				}
			})
			results.recordsets[1].forEach((val, index)  => {
				
				
				
				var details =costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id))
				var costTotal = details.find(o => o.costSheet_id == val.costSheet_id);
				
				if(val.TotalRMC > 10000000){
					RFPwithTotalRMC = RFPwithTotalRMC + 1
				}
				 chemicals = chemicals + costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id && (item.Chemical_category).toLowerCase() === 'project specific' && item.SNo != '')).length
				 chemicalsPer = chemicalsPer + costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id && (item.Chemical_category).toLowerCase() === 'project specific' && item.Percentage_of_the_total_cost > 40 && item.SNo != '')).length
				let noOfRFPsAboveForty = costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id && item.Percentage_of_the_total_cost >40 && item.Chemical_category != 'stage' && item.Chemical_category != 'intermediate' && item.SNo != '')).length
				if(noOfRFPsAboveForty > 0){
					chemicalsPerCon = chemicalsPerCon + 1
				}
				 
				 if(val.FGQty < 50){
					NoOFRFPswithlessthan50kgFGQty = NoOFRFPswithlessthan50kgFGQty + 1
				 }
				 var weeks = costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id && item.Con_CC_in_Kg > 50 && item.SNo != '' && item.Lead_time != ''))
				 var weeksCount = weeks.reduce(function(sum, current) {
						return sum + parseFloat(current.Lead_time);
						}, 0);
				 if(val.FGQty > 50 && weeksCount>5){
					NoOFRFPswithGreterthan50kgFGQty = NoOFRFPswithGreterthan50kgFGQty + 1
				 }
				 
				 
				 
				var avgWeeks =costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id && item.SNo != ''))
				
				let popularitySum = 0;
				let itemsFound = 0;
				const len = avgWeeks.length;
				let item = null;
				for (let i = 0; i < len; i++) {
					item = avgWeeks[i];
					if (item.Lead_time) {
						popularitySum = parseInt(item.Lead_time) + popularitySum;
						itemsFound = itemsFound + 1;
					
					}
				}
				if(itemsFound != 0){
					const average = popularitySum / itemsFound;
					avgLeadTimeByCostsheet = avgLeadTimeByCostsheet + average
				}
				
				if(popularitySum >5){
					NoRFSweeksLeadtime = NoRFSweeksLeadtime + 1
				}
				
				//// Averageweeksforlessthan50kgFGQty
				if(val.FGQty < 50){
					var avgLeadLessFG50Kg = costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id && item.SNo != '' && item.FGQty < 50))
					
					let leadSum = 0;
					let itemFound = 0;
					const avglen = avgLeadLessFG50Kg.length;
					let itemavg = null;
					for (let i = 0; i < avglen; i++) {
						itemavg = avgLeadLessFG50Kg[i];
						if (itemavg.Lead_time) {
							leadSum = parseInt(itemavg.Lead_time) + leadSum;
							itemFound = itemFound + 1;
						
						}
					}
					if(itemFound != 0){
					    var avgLead = leadSum / itemFound;
					}else{
						var avgLead = 0
					}
					avgLeadTimeLessFiftyFGQty = avgLeadTimeLessFiftyFGQty + avgLead
					avgLess50FGCount = avgLess50FGCount + 1
				}
				
			
			/// No of RM's >5 weeks Lead time
				
				NoRMweeksLeadtime = NoRMweeksLeadtime + costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id && item.Lead_time >= 5 && item.Chemical_category != 'stage' && item.Chemical_category != 'intermediate' && item.SNo != '')).length

				TotalNoRMsfromChina = TotalNoRMsfromChina + costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id && item.Country ==='China')).length
				var materialsQuotedFromChina =costSheetDetails.filter(item => (item.costSheet_id === val.costSheet_id && item.Country ==='China'))
				materialsQuotedFromChina.forEach(valueM => {
					if(valueM.Total_Cost_Rs){
						TotalcostFromChaina = TotalcostFromChaina + parseFloat(valueM.Total_Cost_Rs)
					}
				})

		
			})
			var individval = {}
				if(LeadTime.OnTime != 0){
					var onTimePerc = (LeadTime.OnTime/costSheetFiles.length) * 100
				}else{
					var onTimePerc = 0
				}
				if(avgLess50FGCount !=0){
					var FiftyFGQty =avgLeadTimeLessFiftyFGQty / avgLess50FGCount
				}else{
					var FiftyFGQty =0
				} 
				var AverageWeeks = avgLeadTimeByCostsheet/results.recordsets[1].length
				individval['RFPSubmitted'] = costSheetFiles.length
				individval['RFPSubmittedOntime'] = LeadTime.OnTime
				individval['DelaySubmitted'] = LeadTime.Delay
				individval['Onime'] = onTimePerc

				individval['RFPwithTotalRMC'] = RFPwithTotalRMC
				individval['NoProjectSpecificChemicals'] = chemicals
				individval['NoProjectSpecificChemicalsTotalCost'] = chemicalsPer
				individval['chemicalsContribution'] = chemicalsPerCon
				individval['NoRMweeksLeadtime'] = NoRMweeksLeadtime
				individval['NoRFSweeksLeadtime'] = NoRFSweeksLeadtime
				individval['AverageWeeks'] = AverageWeeks
				individval['NoOFRFPswithlessthan50kgFGQty'] = NoOFRFPswithlessthan50kgFGQty
				individval['NoOFRFPswithGreterthan50kgFGQty'] = NoOFRFPswithGreterthan50kgFGQty
				individval['Averageweeksforlessthan50kgFGQty'] = FiftyFGQty
				individval['TotalNoRMsfromChina'] = TotalNoRMsfromChina
				individval['TotalcostFromChaina'] = TotalcostFromChaina 
				
				
		    res.json({error:false,count:results.recordsets[1].length,report:individval});
        }
    });
	 }else{
		 
		  res.json({error:true,message:"Send from date , To date"})
	 }
  }); 
  app.post('/getby-date-main/',(req, res) => {
   var data = req.body;
	if(data.fromDate && data.toDate){
		 var toDate =data.toDate+' 23:59:59.99';	
		 
	let sql = "select * from costSheetFiles WHERE SubmittedDate BETWEEN '"+data.fromDate+"' AND '"+toDate+"'"
	
	db.executeSql(sql, (err, results) => {
        if (err){      
            res.status(500).json({message:err,sql:sql})
        }else{		
			var costSheetDetails = results.recordset
			var LeadTime = {}
			var avgLeadTimeByCostsheet = 0
				var arr = {}
				arr['month'] = data.fromDate + ' to '+data.toDate
				arr['GMPNEW'] = costSheetDetails.filter(item => ((item.GMPorNonGMP).toLowerCase() === 'gmp' && (item.ReloadOrNew).toLowerCase() === 'new')).length
				arr['GMPRELOAD'] = costSheetDetails.filter(item => ((item.GMPorNonGMP).toLowerCase() == 'gmp' && (item.ReloadOrNew).toLowerCase() === 'reload')).length
				arr['NONGMPRELOAD'] = costSheetDetails.filter(item => ((item.GMPorNonGMP).toLowerCase() == 'non-gmp' && (item.ReloadOrNew).toLowerCase() === 'reload')).length
				arr['NONGMPNEW'] = costSheetDetails.filter(item => ((item.GMPorNonGMP).toLowerCase() === 'non-gmp' && (item.ReloadOrNew).toLowerCase() == 'new')).length
				arr['all'] = costSheetDetails.length
				console.log(arr,831)
				res.json({error:false,report:arr});
        }
    });
	 }else{
		 
		  res.json({error:true,message:"Send from date , To date"})
	 }
  });
 app.get('/all-dropdowns', function(req, res){
	let sql = "SELECT ProposalCode FROM quotations GROUP BY ProposalCode;SELECT Received FROM quotations GROUP BY Received;SELECT SubmittedDate FROM quotations GROUP BY SubmittedDate;SELECT Name FROM quotations GROUP BY Name;SELECT CAS_Number FROM quotations GROUP BY CAS_Number;SELECT Unit_Cost_Per_Kg_Rs FROM quotations GROUP BY Unit_Cost_Per_Kg_Rs;SELECT Chemical_category FROM quotations GROUP BY Chemical_category;SELECT Percentage_of_the_total_cost FROM quotations GROUP BY Percentage_of_the_total_cost;SELECT Country FROM quotations GROUP BY Country;SELECT FGQty FROM quotations GROUP BY FGQty;SELECT Con_CC_in_Kg FROM quotations GROUP BY Con_CC_in_Kg;SELECT MadeOfShipment FROM quotations GROUP BY MadeOfShipment;SELECT Source FROM quotations GROUP BY Source;SELECT Lead_time FROM quotations GROUP BY Lead_time;SELECT Min_pack FROM quotations GROUP BY Min_pack;SELECT Remarks FROM quotations GROUP BY Remarks;SELECT Total_Cost_Rs FROM quotations GROUP BY Total_Cost_Rs"
    db.executeSql(sql, (err, results) => {
        if (err){      
            res.status(500).json({message:err,sql:sql})
        }else{
            res.json({count:results.recordset.length,data:results.recordsets});
        }
    });
	 
 })	 
app.get('/getby-costsheetid/:costSheet_id/:qty',(req, res) => {
    let sql = "SELECT * FROM quotations WHERE costSheet_id ='"+req.params.costSheet_id+"'"
    db.executeSql(sql, (err, results) => {
        if (err){      
            res.status(500).json({message:err,sql:sql})
        }else{
            res.json({count:results.recordset.length,data:results.recordset});
        }
    });
  });
 
app.post('/byfgquantity/:id', function(req, res){
    const id = req.params.id;
	var key = req.body.key
	var whereName = ''
	if(key){
		whereName = " AND Name ='"+key+"'"
	}
    var sql = "SELECT * from costSheets where costSheet_id='"+id+"';SELECT * from quotations where costSheet_id='"+id+"';SELECT name from quotations where costSheet_id='"+id+"' "+whereName+" group by name;SELECT name from quotations where costSheet_id='"+id+"' group by name;"
    db.executeSql(sql, function(err, recordset){
        if (err){
		}else{
			var rfcs = recordset.recordsets[0]
			var rfcsDetails = recordset.recordsets[1]
			var MaterialNames = recordset.recordsets[2]
			var MaterialNamesAll = recordset.recordsets[3]
			var names=[]
			MaterialNames.forEach(mName =>{
				if(mName.name !=''){
					var bynameList = {}
					var refMName = rfcsDetails.filter(item => (item.Name === mName.name))
					var Con_CC_in_Kg = refMName.reduce(function(sum, current) {
						  return sum + parseFloat(current.Con_CC_in_Kg);
						}, 0);
					var Total_Cost_Rs = refMName.reduce(function(sum, current) {
						  return sum + parseFloat(current.Total_Cost_Rs);
						}, 0);
					bynameList['ProposalCode'] = refMName[0].ProposalCode
					bynameList['SubmittedDate'] = refMName[0].SubmittedDate
					bynameList['NameMaterial'] = refMName[0].Name
					bynameList['TotalRMC'] = rfcs[0].TotalRMC
					bynameList['fgQuantity'] = refMName[0].quantity
					bynameList['Total_Cost_Rs'] = Total_Cost_Rs
					bynameList['Con_CC_in_Kg'] = Con_CC_in_Kg
					bynameList['costContribution'] = Total_Cost_Rs / rfcs[0].TotalRMC
				names.push(bynameList)
				}
			})
         res.json({error:false,names:names,MaterialNames:MaterialNamesAll})
		}
    });
})

/// DELETE Row in Import Shipment

app.delete('/remove/:quotationId/', function(req, res){
    const id = req.params.id;
    var sql = "DELETE FROM costSheetFiles WHERE Fileid ='"+req.params.quotationId+"';DELETE FROM costSheets WHERE FileId ='"+req.params.quotationId+"'; DELETE FROM quotations WHERE Fileid ='"+req.params.quotationId+"';"
    console.log("query",sql)
    db.executeSql(sql, function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         res.send(recordset)
    });
})

app.post('/remove-multi/', function(req, res){
    const id = req.body.ids;
    var sql = "DELETE FROM costSheetFiles WHERE Fileid IN ("+id+"); DELETE FROM costSheets WHERE FileId IN ("+id+"); DELETE FROM quotations WHERE Fileid IN ("+id+");"
    console.log("query",sql)
    db.executeSql(sql, function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         res.send(recordset)
    });
})
app.delete('/removeAll', function(req, res){
    console.log('connection established')
    const id = req.params.id;
    console.log("ID ID", id)
    var sql = "DELETE FROM costSheets";
    console.log("query",sql)
    db.executeSql(sql, function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         res.send(recordset)
    });
})

  app.get('/getby-dashboard/',(req, res) => {
	var d = new Date();
	var cy = d.getFullYear();
	var getMonth = d.getMonth() + 1;
	var ly = d.getFullYear() - 1;
	var today = d.getFullYear()+'-'+getMonth +'-'+d.getDate()
	var LastYearTodat = ly+'-'+getMonth +'-'+d.getDate()
	
	var previousYearFrom =ly+'-04-01 00:00:00.00';	
	var previousYearTo =cy+'-03-31 23:59:59.99';	
	var ytdFrom =+ly+'-04-01 00:00:00.00';	
	var ytdTo =LastYearTodat+' 23:59:59.99';	
	var currentYearFrom ='2021-04-01 00:00:00.00';	
	var currentYearTo =today+' 23:59:59.99';	
	var mtdFrom =d.getFullYear()+'-'+getMonth+'-01 00:00:00.00';	
	var mtdTo =today+' 23:59:59.99';	
		 
	let sql = "select * from costSheetFiles WHERE SubmittedDate BETWEEN '"+previousYearFrom+"' AND '"+previousYearTo+"';select * from costSheetFiles WHERE SubmittedDate BETWEEN '"+ytdFrom+"' AND '"+ytdTo+"';select * from costSheetFiles WHERE SubmittedDate BETWEEN '"+currentYearFrom+"' AND '"+currentYearTo+"';select * from costSheetFiles WHERE SubmittedDate BETWEEN '"+mtdFrom+"' AND '"+mtdTo+"'"
	
	db.executeSql(sql, (err, results) => {
        if (err){      
            res.status(500).json({message:err,sql:sql})
        }else{		
			var costSheetDetails = results.recordsets
			
				var arr = {}
				arr['sql'] = sql
				arr['previousYear'] = config.costFilesOntime(costSheetDetails[0])
				arr['ytd'] = config.costFilesOntime(costSheetDetails[1])
				arr['currentYear'] = config.costFilesOntime(costSheetDetails[2])
				arr['mtd'] = config.costFilesOntime(costSheetDetails[3])
				res.json({error:false,result:arr,sql:sql});
        }
    });
	 
  });

module.exports = app;
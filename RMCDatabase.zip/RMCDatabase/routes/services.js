'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');
const middleware    = require("../middleware");
const convert  = require('xml-js');

app.post('/changepassword', function(req, res){
    var data = req.body;
    var table = 'gvk_users';
	var id =data.uid;	
	var pass =data.new_password;	
	var sql ="UPDATE gvk_users SET Password='"+pass+"' WHERE id="+id;
	db.executeSql(sql, function(err, recordset){
        if(err)
        console.log('error is:', err)
        else{
	res.send(JSON.stringify({"status": true, "data": data}));	
        }
    });
});

app.post('/signIn', function(req, res){
    var data = req.body;
    if(data.email && data.password){
        var table = 'gvk_users';
        var email =data.email;	
        var pass =data.password;	
        var sql = "select * from gvk_users WHERE email LIKE '"+email+"' AND Password LIKE '"+pass+"'";
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({"message": err});	
            }else{
                if(recordset.recordset.length>0){
                    var sqlSaveSes = "INSERT INTO gvk_userSessions(userId) VALUES";
                    sqlSaveSes += util.format("('%s')",
                    recordset.recordset[0].id); 
                    console.log(sqlSaveSes)
                    db.executeSql(sqlSaveSes, function(err, dataSave){
                        //console.log(dataSave)
                    })
                }
                res.status(200).json({"status": true, "data": recordset.recordset});	
            }
        });
    }else{
        res.status(400).json({"status": true, "message": "Send all required fields"});
    }
});

app.post('/signUp', function (req, res) {
    var data = req.body;
    var user_type = 3;
    var user_status = 1;
    console.log('connection established', data)
    var sql = "INSERT INTO gvk_users (email, password,usertype,status,fullname,username,designation,department) VALUES";
    sql += util.format("('%s','%s','%s','%s','%s','%s','%s','%s')", data.email, data.password, user_type, user_status, data.fullname, data.username, data.designation, data.department)
    db.executeSql(sql, function (err, recordset) {
        if (err) {
            res.status(500).json({"message":err})
        } else {
            res.status(200).json({"status":true,"data":recordset})
        }
    });
});


app.post('/getExportRecords', function(req, res){
    var data = req.body;
    console.log(data)
    if(data.userId && data.key){
    var table = 'gvk_export_records';
	if(data.key){
        var str = data.key;
            var str_array = str.split(',');
                for(var i = 0; i < str_array.length; i++) {
                // Trim the excess whitespace.
                    if(i==0){
                        var key = str_array[0].replace(/^\s*/, "").replace(/\s*$/, "");
                        var whereTracking_No = "Tracking_No LIKE '"+key+"'"
                    }else if(i==1){
                        var key1 = str_array[1].replace(/^\s*/, "").replace(/\s*$/, "");
                        if(key1){
                            var whereTracking_No = "Tracking_No LIKE '"+key+"' OR Tracking_No LIKE '"+key1+"'"
                            }
                    }else if(i==2){
                        var key2 = str_array[2].replace(/^\s*/, "").replace(/\s*$/, "");
                        if(key2){
                            var whereTracking_No = "Tracking_No LIKE '"+key+"' OR Tracking_No LIKE '"+key1+"' OR Tracking_No LIKE '"+key2+"'"
                        }
                    }else if(i==3){
                        var key3 = str_array[3].replace(/^\s*/, "").replace(/\s*$/, "");
                        if(key3){
                            var whereTracking_No = "Tracking_No LIKE '"+key+"' OR Tracking_No LIKE '"+key1+"' OR Tracking_No LIKE '"+key2+"' OR Tracking_No LIKE '"+key3+"'"
                        }
                    }else if(i==4){
                        var key4 = str_array[4].replace(/^\s*/, "").replace(/\s*$/, "");
                        if(key4){
                            var whereTracking_No = "Tracking_No LIKE '"+key+"' OR Tracking_No LIKE '"+key1+"' OR Tracking_No LIKE '"+key2+"' OR Tracking_No LIKE '"+key3+"' OR Tracking_No LIKE '"+key4+"'"
                        }
                    }
                }
                var sql = "select * from gvk_export_shipments WHERE Invoice_No LIKE '"+key+"' OR "+whereTracking_No+" order by Date DESC";
            }else{
                var sql = "select * from gvk_export_shipments";
            }
            db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(200).json({"message": err});
            }else{
                
                if((recordset.recordset.length > 0) && (data.save == 1)){
                    var sqlSaveSearch = "INSERT INTO gvk_saveSearchs(SearchName, userId,type) VALUES";
                    sqlSaveSearch += util.format("('%s','%s','%s')",
                    data.key?data.key:'',data.userId?data.userId:'','export'); 
                    db.executeSql(sqlSaveSearch, function(err, dataSave){
                       // console.log('dataSave',dataSave)
                    })
                }
                var result = recordset.recordset
                if(result.length == 1){ 
                    for(let i=0; i < 1; i++){
                        console.log(i,result[i].AWB_no)
                        var sqlSub = "select Subscribe from gvk_shipmentUpdateSubscriptions where shipmentId="+result[i].id
                        db.executeSql(sqlSub, function(err, recordsSub){
                            console.log(sqlSub)
                            if(recordsSub.recordset.length > 0){
                                result[i]['subscribe'] = recordsSub.recordset[0].Subscribe
                            }else{
                                result[i]['subscribe'] = 0
                            }
                            res.status(200).json({"status": true, "table":table, "record": recordset.recordset});	
                        })  
                    }
                }else{
                    res.status(200).json({"status": true, "table":table, "record": recordset.recordset});
                }	
            }
        });
    }else{
        res.status(400).json({"status": true, "message":"Send required fields"});	
    }
});
app.post('/getImportRecords', function(req, res){
    var data = req.body;
    if(data.userId && data.key){
        var table = 'gvk_import_records';
        if(data.key){
            var str = data.key;
            var str_array = str.split(',');
            for(var i = 0; i < str_array.length; i++) {
            if(i==0){
                    var key = str_array[0].replace(/^\s*/, "").replace(/\s*$/, "");
                    var whereawb = "AWB_no LIKE '"+key+"'"
                    var whereNRM = "NRM LIKE '%"+key+"%'"
                    var whereMPR = "MPR LIKE '%"+key+"%'"
                    var whereBLR = "BLR LIKE '%"+key+"%'"
                    var whereVPO = "VPO LIKE '%"+key+"%'"
            }else if(i==1){
                var key1 = str_array[1].replace(/^\s*/, "").replace(/\s*$/, "");
                    if(key1){
                        var whereawb = "AWB_no LIKE '"+key+"' OR AWB_no LIKE '"+key1+"'"
                        var whereNRM = "NRM LIKE '%"+key+"%' OR NRM LIKE '%"+key1+"%'"
                        var whereMPR = "MPR LIKE '%"+key+"%' OR MPR LIKE '%"+key1+"%'"
                        var whereBLR = "BLR LIKE '%"+key+"%' OR BLR LIKE '%"+key1+"%'"
                        var whereVPO = "VPO LIKE '%"+key+"%' OR VPO LIKE '%"+key1+"%'"
                        }
                }else if(i==2){
                    var key2 = str_array[2].replace(/^\s*/, "").replace(/\s*$/, "");
                    if(key2){
                        var whereawb = "AWB_no LIKE '"+key+"' OR AWB_no LIKE '"+key1+"' OR AWB_no LIKE '"+key2+"'"
                        var whereNRM = "NRM LIKE '%"+key+"%' OR NRM LIKE '%"+key1+"%' OR NRM LIKE '%"+key2+"%'"
                        var whereMPR = "MPR LIKE '%"+key+"%' OR MPR LIKE '%"+key1+"%' OR MPR LIKE '%"+key2+"%'"
                        var whereBLR = "BLR LIKE '%"+key+"%' OR BLR LIKE '%"+key1+"%' OR BLR LIKE '%"+key2+"%'"
                        var whereVPO = "VPO LIKE '%"+key+"%' OR VPO LIKE '%"+key1+"%' OR VPO LIKE '%"+key2+"%'"
                    }
            }else if(i==3){
                    var key3 = str_array[3].replace(/^\s*/, "").replace(/\s*$/, "");
                    if(key3){
                        var whereawb = "AWB_no LIKE '"+key+"' OR AWB_no LIKE '"+key1+"' OR AWB_no LIKE '"+key2+"' OR AWB_no LIKE '"+key3+"'"
                        var whereNRM = "NRM LIKE '%"+key+"%' OR NRM LIKE '%"+key1+"%' OR NRM LIKE '%"+key2+"%' OR NRM LIKE '%"+key3+"%'"
                        var whereMPR = "MPR LIKE '%"+key+"%' OR MPR LIKE '%"+key1+"%' OR MPR LIKE '%"+key2+"%' OR MPR LIKE '%"+key3+"%'"
                        var whereBLR = "BLR LIKE '%"+key+"%' OR BLR LIKE '%"+key1+"%' OR BLR LIKE '%"+key2+"%' OR BLR LIKE '%"+key3+"%'"
                        var whereVPO = "VPO LIKE '%"+key+"%' OR VPO LIKE '%"+key1+"%' OR VPO LIKE '%"+key2+"%' OR VPO LIKE '%"+key3+"%'"
                    }
                }else if(i==4){
                    var key4 = str_array[4].replace(/^\s*/, "").replace(/\s*$/, "");
                    if(key4){
                        var whereawb = "AWB_no LIKE '"+key+"' OR AWB_no LIKE '"+key1+"' OR AWB_no LIKE '"+key2+"' OR AWB_no LIKE '"+key3+"' OR AWB_no LIKE '"+key4+"'"
                        var whereNRM = "NRM LIKE '%"+key+"%' OR NRM LIKE '%"+key1+"%' OR NRM LIKE '%"+key2+"%' OR NRM LIKE '%"+key3+"%' OR NRM LIKE '%"+key4+"%'"
                        var whereMPR = "MPR LIKE '%"+key+"%' OR MPR LIKE '%"+key1+"%' OR MPR LIKE '%"+key2+"%' OR MPR LIKE '%"+key3+"%' OR MPR LIKE '%"+key4+"%'"
                        var whereBLR = "BLR LIKE '%"+key+"%' OR BLR LIKE '%"+key1+"%' OR BLR LIKE '%"+key2+"%' OR BLR LIKE '%"+key3+"%' OR BLR LIKE '%"+key4+"%'"
                        var whereVPO = "VPO LIKE '%"+key+"%' OR VPO LIKE '%"+key1+"%' OR VPO LIKE '%"+key2+"%' OR VPO LIKE '%"+key3+"%' OR VPO LIKE '%"+key4+"%'"
                    }
                }
            }

            var sql= "select * from (select * from gvk_import_shipments WHERE (Vendor_name LIKE '%"+key+"%' OR "+whereNRM+" OR "+whereMPR+" OR "+whereBLR+" OR "+whereVPO+" OR "+whereawb+") AND Pick_up_date>DATEADD(day,-30000,GETDATE()) union select * from gvk_import_shipments WHERE (Vendor_name LIKE '%"+key+"%' OR "+whereNRM+" OR "+whereMPR+" OR "+whereBLR+" OR "+whereVPO+" OR "+whereawb+") AND( Pick_up_date is null or Pick_up_date=''))tbl order by (case when ( Pick_up_date is null or Pick_up_date='')  then 1 else 0  end)desc,Pick_up_date desc";
       }else{
            var sql = "select * from gvk_import_shipments";
        }
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({"message":err});
            }else{
                if((recordset.recordset.length > 0) && (data.save == 1)){
                    var sqlSaveSearch = "INSERT INTO gvk_saveSearchs(SearchName, userId,type) VALUES";
                    sqlSaveSearch += util.format("('%s','%s','%s')",
                    data.key?data.key:'',data.userId?data.userId:'','import'); 
                    console.log(sqlSaveSearch)
                    db.executeSql(sqlSaveSearch, function(err, dataSave){
                      //  console.log(dataSave)
                    })
                }
                var result = recordset.recordset
                if(result.length == 1){ 
                    for(let i=0; i < 1; i++){
                        console.log(i,result[i].AWB_no)
                        var sqlSub = "select Subscribe from gvk_shipmentUpdateSubscriptions where shipmentId="+result[i].id
                        db.executeSql(sqlSub, function(err, recordsSub){
                            console.log(sqlSub)
                            if(recordsSub.recordset.length > 0){
                                result[i]['subscribe'] = recordsSub.recordset[0].Subscribe
                            }else{
                                result[i]['subscribe'] = 0
                            }
                            res.status(200).json({"status": true, "table":table, "record": recordset.recordset});	
                        })  
                    }
                }else{
                    res.status(200).json({"status": true, "table":table, "record": recordset.recordset});
                }
               
            }
        });
    }else{
        res.status(400).json({"message":"Send all required params"});
    }
    
});
app.post('/import-saved-searchs-list', function(req, res){
    if(req.body.userId){
        var data = req.body;
        var id =data.userId;
        var sql ="select * from gvk_saveSearchs WHERE userId='"+id+"' AND type='import'";
        console.log(sql)
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err});	
            }else{
                res.status(200).json({"status": true, "data": recordset.recordset});	
            }
        });
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});
app.post('/export-saved-searchs-list', function(req, res){
    if(req.body.userId){
        var data = req.body;
        var id =data.userId;	
        var sql ="select * from gvk_saveSearchs WHERE userId='"+id+"' AND type='export'";
        console.log(sql)
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err});	
            }else{
                res.status(200).json({"status": true, "data": recordset.recordset});	
            }
        });
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});
app.post('/delete-search', function(req, res){
    if(req.body.userId && req.body.id){
        var data = req.body;
        var userId =data.userId;
        var id =data.id;	
        var sql ="select * from gvk_saveSearchs WHERE userId='"+userId+"' AND Id="+id;
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err});	
            }else{
                if((recordset.rowsAffected.length==0)){
                    var deleteSql ="DELETE from gvk_saveSearchs WHERE userId='"+userId+"' AND Id="+id;
                    db.executeSql(deleteSql, function(errr, deleteData){
                        if(errr){
                            res.status(500).json({ "message": err});
                        }else{
                            res.status(200).json({"status": true, "data": deleteData});	
                        }

                    })
                }else{
                    res.status(400).json({ "message": 'Records not availale'});
                }
            }
        });
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});

app.post('/user-logs', function(req, res){
    if(req.body.userId){
        var data = req.body;
        var userId =data.userId;
        var id =data.id;	
        if(data.fromdate){
             var sql = "SELECT gvk_users.email,gvk_users.usertype,gvk_userSessions.DateCreated,gvk_userSessions.userId FROM gvk_userSessions LEFT JOIN gvk_users ON gvk_userSessions.userId = gvk_users.id WHERE DateCreated BETWEEN '2021-02-22' AND '2021-02-26'";
         }else{
            var sql = "SELECT gvk_users.email,gvk_users.usertype,gvk_userSessions.DateCreated,gvk_userSessions.userId FROM gvk_userSessions LEFT JOIN gvk_users ON gvk_userSessions.userId = gvk_users.id";
         }
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err,sql:sql});	
            }else{
                res.status(200).json({"status": true, "data": recordset.recordset});	
            }
        });
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});

app.post('/user-logs', function(req, res){
    if(req.body.userId){
        var data = req.body;
        var userId =data.userId;
        var id =data.id;	
        if(data.fromdate){
             var sql = "SELECT gvk_users.email,gvk_users.usertype,gvk_userSessions.DateCreated,gvk_userSessions.userId FROM gvk_userSessions LEFT JOIN gvk_users ON gvk_userSessions.userId = gvk_users.id WHERE DateCreated BETWEEN '2021-02-22' AND '2021-02-26'";
         }else{
            var sql = "SELECT gvk_users.email,gvk_users.usertype,gvk_userSessions.DateCreated,gvk_userSessions.userId FROM gvk_userSessions LEFT JOIN gvk_users ON gvk_userSessions.userId = gvk_users.id";
         }
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err,sql:sql});	
            }else{
                res.status(200).json({"status": true, "data": recordset.recordset});	
            }
        });
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});

app.post('/subscribe-shipment', function(req, res){
    if(req.body.userId && req.body.shipmentId && req.body.shipmentType){
            var data = req.body;
            var shipmentId = data.shipmentId
            var shipmentType = data.shipmentType
            var subscribe = data.subscribe
        if(shipmentType =='gvk_import_shipments' || (shipmentType =='gvk_export_shipments')){
            sql = "select "+shipmentType+".* from "+shipmentType+" LEFT JOIN gvk_shipmentUpdateSubscriptions ON "+shipmentType+".id=gvk_shipmentUpdateSubscriptions.shipmentId  where shipmentType = '"+shipmentType+"' AND shipmentId="+shipmentId 
            db.executeSql(sql, function(err, recordset){
                console.log(recordset)
                if(err){
                    res.status(500).json({ "message": err,sql:sql});	
                }else{
                  
                    if(recordset.recordset.length == 0){
                        var sqlSelect = "select * from  "+shipmentType+" Where id="+shipmentId
                        db.executeSql(sqlSelect, function(err, sqlSelect){
						 if(sqlSelect.recordset.length > 0){
                            if(shipmentType =='gvk_import_shipments'){
                                var shipmentStatus = sqlSelect.recordset[0].Status
                             }else if(shipmentType =='gvk_export_shipments')
                             {
                                 var shipmentStatus = sqlSelect.recordset[0].Remarks
                             }else{
                                 var shipmentStatus = ''
                             }
                            var sqlSaveSearch = "INSERT INTO gvk_shipmentUpdateSubscriptions(shipmentId,userId,shipmentType,Status,Subscribe) VALUES";
                                sqlSaveSearch += util.format("('%s','%s','%s','%s','%s')",
                                data.shipmentId?data.shipmentId:'',data.userId?data.userId:'',data.shipmentType?data.shipmentType:'',shipmentStatus?shipmentStatus:'',data.subscribe?data.subscribe:1); 
                                db.executeSql(sqlSaveSearch, function(err, insertData){
                                    
                                    res.status(200).json({"status": data.subscribe, "data": insertData});	
                                })
                          }else{
                            res.status(400).json({"status": true, message:"No data available with shipmentId "+shipmentId});
                          }
                        })
                       
                    }else{
                        if(shipmentType =='gvk_import_shipments'){
                            var shipmentStatus = recordset.recordset[0].Status
                         }else if(shipmentType =='gvk_export_shipments')
                         {
                             var shipmentStatus = recordset.recordset[0].Remarks
                         }else{
                             var shipmentStatus = ''
                         }
     
                        var deleteSql = "UPDATE gvk_shipmentUpdateSubscriptions SET Subscribe = '"+subscribe+"' ,Status ='"+shipmentStatus+"' WHERE shipmentId ='"+data.shipmentId+"'  AND userId ='"+data.userId+"' AND shipmentType = '"+data.shipmentType+"'"
                        db.executeSql(deleteSql, function(err, delData){
                           res.status(200).json({"status": data.subscribe, "data": delData});	
                        })
                    }
                    
                }
            });
        }else{
            res.status(400).json({ "message": 'Send valid shipmentType'});
        }
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});

app.get('/subscribes', function(req, res){
            sql = "select gvk_shipmentUpdateSubscriptions.*,gvk_users.email from gvk_shipmentUpdateSubscriptions LEFT JOIN gvk_users ON gvk_shipmentUpdateSubscriptions.userId = gvk_users.id"
            db.executeSql(sql, function(err, recordset){
                if(err){
                    res.status(500).json({ "message": err,sql:sql});	
                }else{
                    let result = recordset.recordset
                    result.forEach(element => {
                        console.log(element.Status)
                        var shipmentsql = "select * from "+element.shipmentType+" where id=" +element.shipmentId
                        db.executeSql(shipmentsql, function(err, shipmentDetails){
                            if(element.shipmentType =='gvk_import_shipments'){
                                    
                                console.log('shipmentDetails'+element.subscrionId,shipmentDetails.recordset[0].Status)
                                if(shipmentDetails.recordset[0].Status == element.Status){
                                    console.log('ssssssas',shipmentDetails.recordset[0].Status)
                                }else{
                                    
                                    var updateSQl = "UPDATE gvk_shipmentUpdateSubscriptions SET Status ='"+shipmentDetails.recordset[0].Status+"' WHERE subscrionId ="+element.subscrionId
                                    console.log('updateSQl',updateSQl)
                                    db.executeSql(updateSQl, function(err, updateSQlData){
                                        console.log('updateSQlData',updateSQlData)
                                        let mail = {}
                                        mail['email'] = 'ravikumar.p@kairostech.com'
                                        mail['subject'] = 'mail update'
                                        middleware.shipmentUpdate(mail);
                                    })
                                }
                            }else if(element.shipmentType =='gvk_export_shipments'){
                                console.log('export')
                            }
                           
                        })

                    });
                                    
                    res.status(200).json({"status": true, "data": recordset.recordset});	
                }
            });      
});
app.post('/xml', function(req, res){
    var xml = '<?xml version="1.0" encoding="UTF-8"?><source><publisher><![CDATA[Client Name]]></publisher><publisherurl><![CDATA[example.com]]></publisherurl><lastBuildDate><![CDATA[Fri, 09 Feb 2018 05:24:09 UTC]]></lastBuildDate><job><title><![CDATA[Job Title]]></title><date><![CDATA[Fri, 02 Feb 2018 00:00:00 EST]]></date><referencenumber><![CDATA[JOBID12345]]></referencenumber><url><![CDATA[https://jobs.client.com/JOBID12345?rx_source=vendor]]></url><company><![CDATA[Smith Co.]]></company><city><![CDATA[San Antonio]]></city><state><![CDATA[TX]]></state><country><![CDATA[United States]]></country><postalcode><![CDATA[]]></postalcode><salary><![CDATA[]]></salary><education><![CDATA[]]></education><jobtype><![CDATA[]]></jobtype><category><![CDATA[Sales]]></category><experience><![CDATA[]]></experience><sponsored><![CDATA[sponsored 0.00]]></sponsored><description><![CDATA[<b>Job Description</b><br><br>This is the job description.]]></description></job></source>'
    var obj = convert.xml2json(xml, {compact: true, spaces: 4});
    var result = [obj]

let dddd = JSON.parse(result)   
res.send(dddd.source.job);	
              
});
module.exports = app;